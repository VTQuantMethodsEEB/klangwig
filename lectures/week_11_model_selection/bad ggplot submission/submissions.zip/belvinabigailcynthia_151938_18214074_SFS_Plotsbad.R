rm(list=ls())
BMPS <- read.csv("BMPS5.csv")

#housekeeping 1. renaming columns 
names(BMPS)
names(BMPS)[names(BMPS)=="Paper.Title"] <- "Title"
names(BMPS)[names(BMPS)=="BMP.ExplaNAtion.Details"] <- "BMP.Details"
names(BMPS)[names(BMPS)=="Country.or.Province"] <- "Country"
names(BMPS)[names(BMPS)=="Level.of.ecological.organization"] <- "Level.Eco.Org"
names(BMPS)[names(BMPS)=="X..Individals.Per.Rep"] <- "Indvs.Per.Rep"
names(BMPS)[names(BMPS)=="ANAlysis.Type"] <- "Analysis.Type"
names(BMPS)[names(BMPS)=="Direction.of.Effect"] <- "DOE"
names(BMPS)[names(BMPS)=="JourNAl"] <- "Journal"
names(BMPS)[names(BMPS)=="X..Replicates.samples.used.taken"] <- "Replicate.Number"
names(BMPS)[names(BMPS)=="Temperature..C."] <- "Temperature"
names(BMPS)[names(BMPS)=="Statistical.ANAlysis"] <- "Analysis.Details"
names(BMPS)

#2. Getting Rid of blank columns 
BMPS <- subset (BMPS, select = -c(X, X.1, X.2, X.3, X.4, X.5, X.6, X.7, X.8, X.9, X.10, X.11, X.12, X.13, X.14, X.15, X.16))


#3.getting rid fo misspellings/etc in columns I know I'm likely to use
unique(BMPS$BMP.Type)
unique(BMPS$Stressor.Type)
unique(BMPS$Disturbance.Type)
unique(BMPS$Response.Type)
unique(BMPS$Analysis.Type)
unique(BMPS$num.DOE)
unique(BMPS$Title)


#3. adding collumn to convert my DOE character type data to numeric
unique(BMPS$DOE)
BMPS$num.DOE = NA #make a new column called "num.DOE" and fill it with NA
BMPS$num.DOE[BMPS$DOE=="positive"] = 1 #where my original column says "positive", set it equal to 1
BMPS$num.DOE[BMPS$DOE=="negative"] = -1 #where my original column says "positive", set it equal to -1
BMPS$num.DOE[BMPS$DOE== "none" ] = 0 #where my original column says "positive", set it equal to 0
BMPS$num.DOE[BMPS$DOE== "none " ] = 0
unique(BMPS$num.DOE)


#Loading Required Packages
library(ggplot2)
install.packages("gridExtra")
library(gridExtra)
install.packages("viridis")
library(viridis)

#BMP Types by Continent
g1 =ggplot(data=BMPS,aes( x=BMP.Type, fill = BMP.Type))+
  geom_bar(stat = "count")+
  facet_wrap(~Physiographic.region, scales = "free_y")+
  ylab("# Responses")+ #change y axes (use an expression to get a log value)
  xlab("BMP Type") #change x axes
g1

BMPS$DOE[BMPS$DOE== "none " ] = "none"
#BMPS$DOE[BMPS$DOE== "NULL" ] = 

#Direction of Effect for BMP Types
g2 =ggplot(data=BMPS,aes(x=BMP.Type, fill = DOE))+
  geom_bar(stat = "count", position = "stack")+
  ylab("# Responses")+ #change y axes (use an expression to get a log value)
  xlab("BMP Type") + #change x axes
  theme(axis.text.x = element_text(size = 6, angle = 90))
g2
View(BMPS)

BMPS$Continent[BMPS$Continent=="North America "] = "North America"

#BMP Types by continent but one graph
g3 =ggplot(data=BMPS,aes(x=BMP.Type, fill = Continent))+
  geom_bar(stat = "count", position = "stack")+
  ylab("# Responses")+ #change y axes (use an expression to get a log value)
  xlab("BMP Type")+ #change x axes
  theme(axis.text.x = element_text(size = 6, angle = 90)) 
g3

#BMP Types by continent but not stacked 
g4 =ggplot(data=BMPS,aes(x=Continent, fill = BMP.Type))+
  geom_bar(stat = "count", position = "dodge")+
  ylab("# Responses")+ #change y axes (use an expression to get a log value)
  xlab("BMP Type")+ #change x axes
  theme(legend.position = "none", axis.text.x = element_text(size = 6, angle = 90))#switching the axis title to 90 degress so they don't overlap. 
g4


BMPS$BMP.Type[BMPS$BMP.Type=="functioNAl "] = "functional"
BMPS$BMP.Type[BMPS$BMP.Type=="Decomposition"] = "decomposition"
BMPS$BMP.Type[BMPS$BMP.Type=="Biomass"] = "biomass"
BMPS$BMP.Type[BMPS$BMP.Type=="Tissue contamiNAtion"] = "tissue contamination"
BMPS$BMP.Type[BMPS$BMP.Type=="abundance "] = "abundance"

#BMPS$Response.Type[BMPS$Response.Type==""] = NA
Response.Type <- 
  BMPS %>%
  mutate(Response.Type = str_trim(BMPS$Response.Type, side = "both")) %>% 
  group_by(Response.Type) %>% 
  summarise(count = n())

#Response Types by Continent
g5 =ggplot(data=BMPS,aes(x=Continent, fill = Response.Type))+
  geom_bar(stat = "count", position = "dodge")+
  #facet_wrap(~Physiographic.region, scales = "free_y")+
  ylab("# Responses")+ #change y axes (use an expression to get a log value)
  xlab("Response Type")+ #change x axes
  scale_colour_viridis(discrete = T)+
  theme_bw()+
  theme(axis.title=element_text(size=23),
        axis.text=element_text(size=15),
        panel.grid = element_blank(), 
        axis.line=element_line(),
        axis.text.x = element_text(size = 6, angle = 90, hjust = 1,face="italic"),
        legend.position="right",
        legend.title = element_blank(),
        legend.text = element_text(size=20),
        legend.background = element_blank(),
        legend.key=element_rect(fill="white",color="white"))
g5

#Response Types by BMP Type 
g6 =ggplot(data=BMPS,aes(x=BMP.Type, fill = Response.Type))+
  geom_bar(stat = "count", position = "dodge")+
  #facet_wrap(~Physiographic.region, scales = "free_y")+
  ylab("# Papers")+ #change y axes (use an expression to get a log value)
  xlab("BMP Type")+ #change x axes
  scale_colour_viridis(discrete = T)+
  theme_bw()+
  theme(axis.title=element_text(size=23),
        axis.text=element_text(size=15),
        panel.grid = element_blank(), 
        axis.line=element_line(),
        axis.text.x = element_text(size = 6, angle = 90, hjust = 1,face="italic"),
        legend.position="right",
        legend.title = element_blank(),
        legend.text = element_text(size=20),
        legend.background = element_blank(),
        legend.key=element_rect(fill="white",color="white"))
g6

Continent <- c("Africa", "Asia", "Australia", "Europe","Latin America", "New Zealand", "North America", "South America" )
#Continent <- c(1, 2, 3, 4, 5, 6, 7, 8 )
Papers <- c(1, 1, 2, 5, 3, 2, 29, 1)

df <- data.frame(Continent, Papers)
View(df)

barplot(Papers~Continent)

?geom_col()
geom_col(data = df. )

#number papers per continent(comparison of aesthetics)

g8 =ggplot(data=df,aes(x=Continent, y = Papers, fill = Continent))+
  geom_col(stat = "count", position = "stack")+
  ylab("# Papers")+ #change y axes (use an expression to get a log value)
  xlab("Continent") + #change x axes
  theme(axis.text.x = element_text(size = 6, angle = 90))
g8

g9 =ggplot(data=df,aes(x=Continent, y = Papers, fill = Continent))+
  geom_col()+
  ylab("# Papers")+ #change y axes (use an expression to get a log value)
  xlab("Continent")+ #change x axes
  scale_colour_viridis(discrete = T)+
  theme_bw()+
  theme(axis.title=element_text(size=23),
        axis.text=element_text(size=15),
        panel.grid = element_blank(), 
        axis.line=element_line(),
        axis.text.x = element_text(size = 6, angle = 90, hjust = 1,face="italic"),
        legend.position="right",
        legend.title = element_blank(),
        legend.text = element_text(size=20),
        legend.background = element_blank(),
        legend.key=element_rect(fill="white",color="white"))
g9

g10 =ggplot(data=BMPS,aes(x=Continent, y = Response.Type, fill = Physiographic.region))+
  geom_col(stat = "count", position = "stack")+
  ylab("# Responses")+ #change y axes (use an expression to get a log value)
  xlab("Physiographic Region") + #change x axes
  theme(axis.text.x = element_text(size = 6, angle = 90))
g10



#boxplot

BMP.Type <- BMPS$BMP.Type
meanval <- BMPS$Mean.Values.for.BMP

Type_norm <- rnorm(200,mean=mean(BMP.Type, na.rm=TRUE), sd=sd(BMP.Type, na.rm=TRUE))
means_norm <- rnorm(200,mean=mean(meanval, na.rm=TRUE), sd=sd(meanval, na.rm=TRUE))
View(BMPS)

boxplot(airquality$Ozone)
